package com.goodee.vo;

public class InnerVO {
	//private List<String> months;
	private String month; //7_1
	private String content; //10

	
	
	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	
}
